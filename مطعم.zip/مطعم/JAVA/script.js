$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
    margin: 15,
    loop: true,
    autoplay: true,
    autoplayTimeout: 3000,
    nav: true,
    responsive: {
      0: { items: 1 },
      768: { items: 2 },
      1000: { items: 3 }
    }
  });
});
$(document).ready(function() {
    // تصفية قائمة الطعام حسب التصنيف
    $('.filter-btn').on('click', function() {
        // إزالة الفئة النشطة من جميع الأزرار وإضافتها للزر المضغوط
        $('.filter-btn').removeClass('active');
        $(this).addClass('active');

        var category = $(this).attr('data-filter');

        if (category === 'all') {
            $('.section-grid .card').fadeIn(400);
        } else {
            $('.section-grid .card').each(function() {
                if ($(this).attr('data-category') === category) {
                    $(this).fadeIn(400);
                } else {
                    $(this).fadeOut(200);
                }
            });
        }
    });

    // تفاعل زر "اطلب الان"
    $('.order-btn').on('click', function() {
        var dishName = $(this).closest('.card').find('h3').text();
        alert('تم إضافة "' + dishName + '" إلى سلة الطلبات بنجاح! 🛒');
    });
});
document.addEventListener("DOMContentLoaded", function () {
    const bookBtn = document.getElementById("book-ticket");
    const bookingSection = document.getElementById("booking-section");

    // إنشاء طبقة خلفية مظلمة تفاعلية
    const overlay = document.createElement("div");
    overlay.className = "booking-overlay";
    document.body.appendChild(overlay);

    // عند الضغط على زر الحجز
    bookBtn.addEventListener("click", function (e) {
        e.preventDefault(); // منع الانتقال لأي رابط صفحة أخرى
        bookingSection.classList.toggle("show-booking");
        overlay.classList.toggle("show-overlay");
    });

    // إخفاء الكارد عند الضغط على الخلفية المظلمة خارج السكشن
    overlay.addEventListener("click", function () {
        bookingSection.classList.remove("show-booking");
        overlay.classList.remove("show-overlay");
    });
});